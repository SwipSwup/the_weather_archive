const { Client } = require('pg');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { createClient } = require("redis");

const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    ssl: { rejectUnauthorized: false }
};

const s3 = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

// Initialize Redis Client
let redisClient;

if (process.env.REDIS_URL) {
    redisClient = createClient({
        url: process.env.REDIS_URL,
        socket: {
            connectTimeout: 500, // Fail fast
            reconnectStrategy: (retries) => {
                if (retries > 3) return new Error('Retry limit exceeded');
                return Math.min(retries * 50, 2000);
            }
        }
    });

    redisClient.on('error', (err) => {
        console.warn('Redis Client Error:', err.message);
    });
}

exports.handler = async (event) => {
    // Basic CORS headers
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
    };

    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers, body: '' };
    }

    const { queryStringParameters } = event;
    const rawCity = queryStringParameters?.city;
    const city = rawCity ? rawCity.toLowerCase() : null; // Normalize for DB Query
    const dateStr = queryStringParameters?.date;

    // Connect to Redis if needed
    if (redisClient && !redisClient.isOpen) {
        try {
            await redisClient.connect();
        } catch (err) {
            console.warn("Failed to connect to Redis:", err.message);
        }
    }

    // --- Redis Cache Check ---
    let cacheKey = null;
    if (redisClient && redisClient.isOpen) {
        if (!city) {
            cacheKey = `weather:latest`;
        } else if (city) {
            if (dateStr) {
                cacheKey = `weather:city:${city}:date:${dateStr}`;
            } else {
                cacheKey = `weather:city:${city}:latest`;
            }
        }

        if (cacheKey) {
            try {
                const cachedData = await redisClient.get(cacheKey);
                if (cachedData) {
                    console.log(`Cache Hit for ${cacheKey}`);
                    return {
                        statusCode: 200,
                        headers,
                        body: cachedData
                    };
                }
            } catch (err) {
                console.warn("Redis Get Error:", err.message);
            }
        }
    }

    console.log(`Processing request for city: ${city}, date: ${dateStr}`);

    const client = new Client(dbConfig);
    try {
        await client.connect();

        // Ensure tables exist
        await client.query(`
            CREATE TABLE IF NOT EXISTS weather_captures (
                id SERIAL PRIMARY KEY,
                filename TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                city TEXT,
                device_id TEXT,
                temperature DECIMAL,
                humidity DECIMAL,
                pressure DECIMAL
            );
            CREATE TABLE IF NOT EXISTS daily_videos (
                id SERIAL PRIMARY KEY,
                city TEXT,
                date DATE,
                video_url TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        let responseData = { images: [], video: null };

        if (!city) {
            // Default "all" query (legacy)
            const res = await client.query('SELECT * FROM weather_captures ORDER BY timestamp DESC LIMIT 50');
            responseData = res.rows;
        } else {
            // Specific City Query
            let imageQuery = 'SELECT * FROM weather_captures WHERE city ILIKE $1';
            const imageParams = [city];

            if (dateStr) {
                // Filter by date
                imageQuery += ' AND DATE(timestamp) = $2 ORDER BY timestamp ASC';
                imageParams.push(dateStr);

                // Fetch Video
                const videoRes = await client.query('SELECT video_url FROM daily_videos WHERE city ILIKE $1 AND date = $2', [city, dateStr]);
                if (videoRes.rows.length > 0) {
                    const videoKey = videoRes.rows[0].video_url;

                    // Generate Presigned URL
                    if (videoKey && process.env.VIDEOS_BUCKET_NAME) {
                        try {
                            const command = new GetObjectCommand({
                                Bucket: process.env.VIDEOS_BUCKET_NAME,
                                Key: videoKey
                            });
                            // Expires in 1 hour
                            const signedUrl = await getSignedUrl(s3, command, { expiresIn: 3600 });
                            responseData.video = signedUrl;
                        } catch (s3Err) {
                            console.error("Failed to sign video URL:", s3Err);
                            responseData.video = null;
                        }
                    } else {
                        responseData.video = videoKey; // Fallback
                    }
                }
            } else {
                // Latest 50
                imageQuery += ' ORDER BY timestamp DESC LIMIT 50';
            }

            const imageRes = await client.query(imageQuery, imageParams);
            responseData.images = imageRes.rows;

            // Generate Thumbnail (First Frame)
            if (responseData.images.length > 0 && process.env.PROCESSED_BUCKET_NAME) {
                try {
                    const firstImg = responseData.images[0];
                    const cmd = new GetObjectCommand({
                        Bucket: process.env.PROCESSED_BUCKET_NAME,
                        Key: firstImg.filename
                    });
                    const thumbUrl = await getSignedUrl(s3, cmd, { expiresIn: 3600 });
                    responseData.thumbnail = thumbUrl;
                } catch (err) {
                    console.warn("Failed to sign thumbnail:", err);
                }
            }
        }

        const resultBody = JSON.stringify(responseData);

        // --- Store in Redis ---
        if (redisClient && cacheKey && redisClient.isOpen) {
            // Fire and forget
            redisClient.set(cacheKey, resultBody, { EX: 3500 })
                .then(() => console.log(`Cached ${cacheKey}`))
                .catch(err => console.warn("Redis Set Error:", err.message));
        }

        return {
            statusCode: 200,
            headers,
            body: resultBody
        };
    } catch (err) {
        console.error("Database Query Error:", err);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: err.message })
        };
    } finally {
        await client.end();
    }
};
